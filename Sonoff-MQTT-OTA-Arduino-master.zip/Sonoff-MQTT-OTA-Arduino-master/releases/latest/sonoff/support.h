#ifdef __cplusplus
extern "C" {
#endif

#ifndef __SUPPORT_H__
#define __SUPPORT_H__

#include "user_interface.h"

/* Function prototypes. */
void WIFI_wps_status_cb(wps_cb_status status);

#endif // ifndef __SUPPORT_H__

#ifdef __cplusplus
}
#endif
