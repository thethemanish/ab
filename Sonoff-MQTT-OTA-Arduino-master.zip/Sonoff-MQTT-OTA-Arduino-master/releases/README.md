## Releases
History of major releases.

See ```sonoff/_releasenotes.ino``` for change information.

See [my Wiki](https://github.com/arendst/Sonoff-MQTT-OTA-Arduino/wiki) for more information.
